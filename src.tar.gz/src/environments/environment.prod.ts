export const environment = {
  production: true,
  API_ENDPOINT: 'http://devservices.greenroom6.com:9000/api/1.0',
  API_IMAGE: 'http://d206s58i653k1q.cloudfront.net/'
};
