import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'spotfeed-card',
  templateUrl: './spotfeed-card.component.html',
  styleUrls: ['./spotfeed-card.component.scss']
})
export class SpotfeedCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
