import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'home-right-block',
  templateUrl: './home-right-block.component.html',
  styleUrls: ['./home-right-block.component.scss']
})
export class HomeRightBlockComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
