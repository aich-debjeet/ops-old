import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationBasicComponent } from './registration-basic.component';

describe('RegistrationBasicComponent', () => {
  let component: RegistrationBasicComponent;
  let fixture: ComponentFixture<RegistrationBasicComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistrationBasicComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationBasicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
