import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationProfileComponent } from './registration-profile.component';

describe('RegistrationProfileComponent', () => {
  let component: RegistrationProfileComponent;
  let fixture: ComponentFixture<RegistrationProfileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistrationProfileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
