import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchCommunityComponent } from './search-community.component';

describe('SearchCommunityComponent', () => {
  let component: SearchCommunityComponent;
  let fixture: ComponentFixture<SearchCommunityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchCommunityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchCommunityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
