import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-post',
  templateUrl: './search-post.component.html',
  styleUrls: ['./../search-icon.component.scss']
})
export class SearchPostComponent implements OnInit {
cards: any=[];
  constructor() { }

  ngOnInit() {
  }

}
