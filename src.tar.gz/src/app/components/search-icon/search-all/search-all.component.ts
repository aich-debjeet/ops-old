import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-all',
  templateUrl: './search-all.component.html',
  styleUrls: ['./../search-icon.component.scss']
})
export class SearchAllComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
