import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-channel',
  templateUrl: './search-channel.component.html',
  styleUrls: ['./../search-icon.component.scss']
})
export class SearchChannelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
