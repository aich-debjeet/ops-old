import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchSpotfeedComponent } from './search-spotfeed.component';

describe('SearchSpotfeedComponent', () => {
  let component: SearchSpotfeedComponent;
  let fixture: ComponentFixture<SearchSpotfeedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchSpotfeedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchSpotfeedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
