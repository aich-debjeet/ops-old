import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-widget-projects',
  templateUrl: './dashboard-widget-projects.component.html',
  styleUrls: ['./dashboard-widget-projects.component.css']
})
export class DashboardWidgetProjectsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
