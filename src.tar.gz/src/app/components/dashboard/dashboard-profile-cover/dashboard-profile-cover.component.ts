import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-profile-cover',
  templateUrl: './dashboard-profile-cover.component.html',
  styleUrls: ['./dashboard-profile-cover.component.css']
})
export class DashboardProfileCoverComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
