import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-secondary-navbar',
  templateUrl: './dashboard-secondary-navbar.component.html',
  styleUrls: ['./dashboard-secondary-navbar.component.css']
})
export class DashboardSecondaryNavbarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
