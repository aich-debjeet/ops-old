import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-widget-opportunities',
  templateUrl: './dashboard-widget-opportunities.component.html',
  styleUrls: ['./dashboard-widget-opportunities.component.css']
})
export class DashboardWidgetOpportunitiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
