import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-widget-communities',
  templateUrl: './dashboard-widget-communities.component.html',
  styleUrls: ['./dashboard-widget-communities.component.css']
})
export class DashboardWidgetCommunitiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
