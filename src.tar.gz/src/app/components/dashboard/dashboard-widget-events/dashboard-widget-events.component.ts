import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-widget-events',
  templateUrl: './dashboard-widget-events.component.html',
  styleUrls: ['./dashboard-widget-events.component.css']
})
export class DashboardWidgetEventsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
