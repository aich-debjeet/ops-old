import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-widget-calendar',
  templateUrl: './dashboard-widget-calendar.component.html',
  styleUrls: ['./dashboard-widget-calendar.component.css']
})
export class DashboardWidgetCalendarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
