import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SpotfeedComponent } from './spotfeed.component';

describe('SpotfeedComponent', () => {
  let component: SpotfeedComponent;
  let fixture: ComponentFixture<SpotfeedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SpotfeedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SpotfeedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
