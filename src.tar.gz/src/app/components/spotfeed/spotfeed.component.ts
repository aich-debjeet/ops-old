import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spotfeed',
  templateUrl: './spotfeed.component.html',
  styleUrls: ['./spotfeed.component.css']
})
export class SpotfeedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
