import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spotfeed-premium',
  templateUrl: './spotfeed-premium.component.html',
  styleUrls: ['./spotfeed-premium.component.css']
})
export class SpotfeedPremiumComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
