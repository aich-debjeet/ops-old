import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-logout-home',
  templateUrl: './logout-home.component.html',
  styleUrls: ['./logout-home.component.scss']
})
export class LogoutHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
