import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutAwardsComponent } from './about-awards.component';

describe('AboutAwardsComponent', () => {
  let component: AboutAwardsComponent;
  let fixture: ComponentFixture<AboutAwardsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AboutAwardsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutAwardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
