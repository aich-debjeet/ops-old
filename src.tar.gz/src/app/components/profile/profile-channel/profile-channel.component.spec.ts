import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfileChannelComponent } from './profile-channel.component';

describe('ProfileChannelComponent', () => {
  let component: ProfileChannelComponent;
  let fixture: ComponentFixture<ProfileChannelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfileChannelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfileChannelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
