import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PasswordSmsComponent } from './password-sms.component';

describe('PasswordSmsComponent', () => {
  let component: PasswordSmsComponent;
  let fixture: ComponentFixture<PasswordSmsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PasswordSmsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PasswordSmsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
