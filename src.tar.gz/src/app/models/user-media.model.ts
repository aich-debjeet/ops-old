export class UserMedia {
 name: string;
}
