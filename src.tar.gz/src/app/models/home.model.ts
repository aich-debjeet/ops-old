export class Channel {
 completed: string[];
 loading = false;
 success = true;
}
