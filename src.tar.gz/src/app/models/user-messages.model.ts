export class UserMessages { }
