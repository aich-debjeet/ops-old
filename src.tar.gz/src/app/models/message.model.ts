export class Message {
 content: string;
}
